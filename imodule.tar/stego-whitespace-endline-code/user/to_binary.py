def text_to_binary(text):
    """Convert message to binary format"""
    binary = ''
    for char in text:
        binary += format(ord(char), '08b')
    return binary

if __name__ == "__main__":
    try:
        with open('message.txt', 'r', encoding='utf-8') as f:
            message = f.read()
        
        binary = text_to_binary(message)
        print("Message to hide:", message)
        print("Binary format:", binary)
        
        with open('binary.txt', 'w') as f:
            f.write(binary)
            
    except FileNotFoundError:
        print("message.txt not found")
    except Exception as e:
        print(f"Error: {e}")
