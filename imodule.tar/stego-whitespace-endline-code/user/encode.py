def hide_message(binary_message, cover_text):
    """Hide binary message in text using whitespace"""
    lines = cover_text.splitlines()
    
    if len(lines) < len(binary_message):
        raise ValueError('Cover text too short to hide message')

    stego_text = []
    for i, line in enumerate(lines):
        if i < len(binary_message):
            trimmed_line = line.rstrip()
            stego_text.append(trimmed_line + (' ' if binary_message[i] == '0' else '  '))
        else:
            stego_text.append(line)
    
    return '\n'.join(stego_text)

if __name__ == "__main__":
    try:
        with open('binary.txt', 'r') as f:
            binary_message = f.read()
            
        with open('cover.txt', 'r', encoding='utf-8') as f:
            cover_text = f.read()

        stego_text = hide_message(binary_message, cover_text)
        
        with open('stego.txt', 'w', encoding='utf-8') as f:
            f.write(stego_text)
            
        print("Successfully hidden message in stego.txt")
        
    except FileNotFoundError as e:
        print(f"File not found: {e.filename}")
    except Exception as e:
        print(f"Error: {e}")
