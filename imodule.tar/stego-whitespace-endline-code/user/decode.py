import sys

def extract_message(stego_text):
    """Extract hidden message from text"""
    lines = stego_text.splitlines()
    
    binary = ''
    for line in lines:
        trailing_spaces = len(line) - len(line.rstrip())
        binary += '1' if trailing_spaces == 2 else '0'

    text = ''
    for i in range(0, len(binary), 8):
        byte = binary[i:i+8]
        if len(byte) == 8:  
            text += chr(int(byte, 2))
    
    return text

if __name__ == "__main__":
    try:
        filename = sys.argv[1] if len(sys.argv) > 1 else 'stego.txt'
        
        with open(filename, 'r', encoding='utf-8') as f:
            stego_text = f.read()
            
        hidden_message = extract_message(stego_text)
        print(f"Hidden message from {filename}:", hidden_message)
        
    except FileNotFoundError:
        print(f"File not found: {filename}")
    except Exception as e:
        print(f"Error: {e}")
